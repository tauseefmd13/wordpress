<?php

namespace Zprint\Exception;

class DB extends \Exception
{
	const NOT_FOUND = 404;
}
