<?php


interface IconnectSettings
{
    const EMAIL_SETTINGS  = 'woocommerce_iconnect-api-integration-email-editor_settings';
    const GLOBAL_SETTINGS = 'woocommerce_iconnect-api-integration_settings';
    const VENDOR_SETTINGS = 'printerco_vendor_settings';
}