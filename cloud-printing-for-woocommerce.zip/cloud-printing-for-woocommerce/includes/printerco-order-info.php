<?php

class OrderType
{
    const Delivery = 1;
    const Collection = 2;
    const Reservation = 3;
    const EatIn = 4;
}
class OrderPaymentStatus
{
    const Paid = 6;
    const NotPaid = 7;
}