<?php


interface IconnectValidationOptions
{
    const DEFAULT_TRANSLATE_DOMAIN = 'woocommerce-iconnect-api-integration';
    const FLASH_NOTICE_OPTION = 'my_flash_notices';
}