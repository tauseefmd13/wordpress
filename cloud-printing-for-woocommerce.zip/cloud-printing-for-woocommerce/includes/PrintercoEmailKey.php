<?php


class PrintercoEmailKey
{
    const ORDER_ID_KEY = "[order_id]";
    const SITE_NAME_KEY = "[site_name]";
    const PROCESSING_TIME_KEY = "[processing_time]";
    const AGREED_TIME_KEY = "[agreed_time]";
    const REJECTED_MESSAGE_KEY = "[rejected_message]";
    const CUSTOMER_NAME_KEY = "[customer_name]";

    public function __construct()
    {
    }
}