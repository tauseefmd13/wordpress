<?php


class PrintercoPluginsSuport
{
    const WOOCOMMERCE_DELIVERY = "woocommerce-delivery/woocommerce-delivery.php";

}